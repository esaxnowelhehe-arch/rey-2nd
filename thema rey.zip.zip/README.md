# REY2ND — Pterodactyl Panel Theme

A midnight-navy and ice-blue appearance theme for **Pterodactyl Panel 2.0**. It uses the official 2.0 theme format and the artwork supplied for this project.

## What's included

- `theme.json` — theme metadata (`id: rey2nd`)
- `tokens.css` — color, shape, terminal palette, and background styling
- `assets/background.jpg` — optimized background artwork

## Requirements

- Pterodactyl Panel **2.0**
- Access to the Panel server's files and terminal

Pterodactyl 2.0 is documented as an open beta. Test the theme on a staging/test panel before applying it to a production panel.

## Install

From the root of your Pterodactyl installation:

```bash
cd /var/www/pterodactyl
mkdir -p themes/rey2nd
```

Upload/copy the contents of this repository into `/var/www/pterodactyl/themes/rey2nd/`, so the final structure is:

```text
/var/www/pterodactyl/themes/rey2nd/
├── theme.json
├── tokens.css
└── assets/
    └── background.jpg
```

Then list and apply the theme:

```bash
php artisan p:theme:list
php artisan p:theme:apply rey2nd
```

Reload the Panel in your browser. If you edit the theme later, run the apply command again.

## Roll back

To restore the Panel's default appearance:

```bash
cd /var/www/pterodactyl
php artisan p:theme:reset
```

## Notes

- This is an **appearance-only theme**. It does not add dashboard widgets, new pages, JavaScript behavior, or server-management features.
- The official 2.0 theme system uses `theme.json`, `tokens.css`, and an optional `assets/` folder.
- Keep a backup of your Panel before changing production files.
- Only install themes you trust; themes run with the same access as the Panel.

## Credits

Theme: **REY2ND**  
Design direction: midnight navy / ice blue  
Artwork: user-provided image, optimized for this theme
