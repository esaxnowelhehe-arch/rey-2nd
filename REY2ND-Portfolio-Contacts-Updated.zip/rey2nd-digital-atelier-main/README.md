# REY2ND — Digital Portfolio

Portofolio pribadi REY2ND dengan tema dark-purple, layout responsif, showcase proyek, daftar keahlian, dan intro soundtrack.

## Menjalankan secara lokal

Persyaratan: Node.js versi yang kompatibel dan npm.

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
npm run preview
```

## Deploy

Project ini menggunakan React, TypeScript, TanStack Start, dan Vite. Untuk deployment, gunakan platform yang mendukung aplikasi TanStack Start/SSR atau sesuaikan konfigurasi build menjadi static export sebelum deploy ke hosting statis seperti Cloudflare Pages.

## Kustomisasi

- Konten halaman utama: `src/routes/index.tsx`
- Warna dan tipografi: `src/styles.css`
- Judul dan metadata global: `src/routes/__root.tsx`

Soundtrack intro menggunakan Spotify embed. Pengunjung perlu menekan tombol play pada player karena browser biasanya memblokir autoplay bersuara.
