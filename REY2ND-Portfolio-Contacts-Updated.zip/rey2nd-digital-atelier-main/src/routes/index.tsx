import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "REY2ND — Digital Creator & Developer" },
      { name: "description", content: "Portofolio REY2ND — website, bot, aplikasi, dan eksperimen digital." },
      { property: "og:title", content: "REY2ND — Digital Creator & Developer" },
      { property: "og:description", content: "Membangun ide menjadi karya digital." },
      { property: "og:type", content: "website" },
      { name: "theme-color", content: "#090711" },
    ],
  }),
  component: Index,
});

const NAV = [
  { id: "about", label: "Tentang" },
  { id: "projects", label: "Proyek" },
  { id: "skills", label: "Keahlian" },
  { id: "contact", label: "Kontak" },
];

const PROJECTS = [
  {
    number: "01",
    name: "ZENITH AI",
    type: "AI ASSISTANT · WEB",
    description: "Konsep asisten AI dengan ruang chat, personalisasi, dan pengalaman digital yang dirancang fleksibel.",
    tags: ["AI", "Web App", "Interface"],
    status: "Personal project",
  },
  {
    number: "02",
    name: "XERAX AI",
    type: "AI PLATFORM · WEB",
    description: "Eksplorasi platform AI dengan fokus pada percakapan, model pilihan, dan pengalaman pengguna.",
    tags: ["AI", "Automation", "Web"],
    status: "In development",
  },
  {
    number: "03",
    name: "ZETERNAL-XEN",
    type: "COMMUNITY · BOT · ANDROID",
    description: "Ekosistem proyek komunitas yang mencakup bot Telegram, tools, dan eksperimen aplikasi.",
    tags: ["Telegram", "Bot", "Community"],
    status: "Selected work",
  },
];

const SKILLS = [
  { title: "WEB DEVELOPMENT", items: ["HTML", "CSS", "JavaScript", "TypeScript", "React"] },
  { title: "TOOLS & RUNTIME", items: ["Node.js", "Git", "Cloudflare", "Termux"] },
  { title: "CREATIVE BUILDING", items: ["UI Design", "Bot Development", "Automation", "Prototyping"] },
];

function useReveal() {
  useEffect(() => {
    const elements = document.querySelectorAll(".reveal");
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      }),
      { threshold: 0.08 },
    );
    elements.forEach((element) => observer.observe(element));
    return () => observer.disconnect();
  }, []);
}

function Index() {
  useReveal();
  const [introOpen, setIntroOpen] = useState(true);
  const [menuOpen, setMenuOpen] = useState(false);
  const [active, setActive] = useState("top");

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((entry) => {
        if (entry.isIntersecting) setActive(entry.target.id);
      }),
      { rootMargin: "-35% 0px -55% 0px" },
    );
    ["top", ...NAV.map((item) => item.id)].forEach((id) => {
      const element = document.getElementById(id);
      if (element) observer.observe(element);
    });
    return () => observer.disconnect();
  }, []);

  const enterPortfolio = () => {
    setIntroOpen(false);
    window.setTimeout(() => window.scrollTo({ top: 0, behavior: "smooth" }), 40);
  };

  return (
    <div className="relative min-h-screen overflow-x-hidden bg-background">
      <div aria-hidden className="pointer-events-none fixed inset-0 -z-0">
        <div className="grid-bg absolute inset-0 opacity-50" />
        <div className="animate-orb absolute -left-40 top-20 h-96 w-96 rounded-full bg-violet/20 blur-[130px]" />
        <div className="animate-orb absolute -right-40 top-[35%] h-[30rem] w-[30rem] rounded-full bg-electric/15 blur-[140px] [animation-delay:-6s]" />
      </div>

      {introOpen && (
        <div className="fixed inset-0 z-[100] flex min-h-screen items-center justify-center overflow-y-auto bg-[#080711] px-5 py-10">
          <div aria-hidden className="pointer-events-none absolute inset-0">
            <div className="grid-bg absolute inset-0 opacity-60" />
            <div className="absolute left-1/2 top-1/2 h-[28rem] w-[28rem] -translate-x-1/2 -translate-y-1/2 rounded-full bg-violet/20 blur-[130px]" />
          </div>
          <div className="relative z-10 w-full max-w-xl text-center">
            <div className="mx-auto mb-8 flex h-16 w-16 items-center justify-center rounded-2xl border border-primary/30 bg-primary/10 font-display text-2xl font-extrabold text-gradient shadow-[0_0_60px_-15px_var(--violet)]">
              R.
            </div>
            <p className="font-mono text-[11px] tracking-[0.35em] text-primary">WELCOME TO MY DIGITAL SPACE</p>
            <h1 className="mt-5 font-display text-5xl font-extrabold tracking-[-0.07em] sm:text-7xl">
              REY<span className="text-gradient">2ND</span>
            </h1>
            <p className="mx-auto mt-4 max-w-md text-sm leading-7 text-muted-foreground sm:text-base">
              Sebelum masuk, nikmati dulu soundtrack pilihan. Putar musiknya, lalu masuk ke portofolio.
            </p>
            <div className="glass mt-9 rounded-3xl p-3 text-left sm:p-4">
              <div className="mb-3 flex items-center justify-between px-2">
                <div>
                  <p className="font-mono text-[10px] tracking-[0.2em] text-primary">INTRO SOUNDTRACK</p>
                  <p className="mt-1 text-sm font-semibold text-foreground">Takkan Terganti</p>
                </div>
                <span className="rounded-full border border-primary/30 px-3 py-1 font-mono text-[10px] text-primary">PLAY FIRST</span>
              </div>
              <iframe
                title="Putar soundtrack intro REY2ND"
                src="https://open.spotify.com/embed/track/0T4t1PywlNmJGcveGH5spB?utm_source=generator&theme=0"
                width="100%"
                height="152"
                loading="eager"
                allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
                className="rounded-2xl border-0"
              />
            </div>
            <button
              type="button"
              onClick={enterPortfolio}
              className="bg-gradient-brand mt-7 inline-flex w-full items-center justify-center gap-3 rounded-full px-7 py-4 text-sm font-bold text-white shadow-[0_12px_45px_-12px_var(--violet)] transition hover:scale-[1.02] sm:w-auto"
            >
              MASUK PORTOFOLIO <span aria-hidden>↗</span>
            </button>
            <p className="mt-4 font-mono text-[10px] tracking-widest text-muted-foreground">SCROLL LESS · CREATE MORE</p>
          </div>
        </div>
      )}

      <header className="fixed inset-x-0 top-0 z-50 px-4 pt-4">
        <nav className="glass mx-auto flex max-w-6xl items-center justify-between rounded-full px-5 py-3 shadow-2xl">
          <a href="#top" className="font-display text-lg font-extrabold tracking-tight">
            REY<span className="text-gradient">2ND</span><span className="ml-2 font-mono text-[9px] font-normal tracking-[0.2em] text-muted-foreground">/ PORTFOLIO</span>
          </a>
          <ul className="hidden items-center gap-1 md:flex">
            {NAV.map((item) => (
              <li key={item.id}>
                <a href={`#${item.id}`} className={`rounded-full px-4 py-2 text-xs transition ${active === item.id ? "bg-primary/15 text-primary" : "text-muted-foreground hover:text-foreground"}`}>
                  {item.label}
                </a>
              </li>
            ))}
          </ul>
          <a href="#contact" className="hidden rounded-full border border-primary/40 px-4 py-2 text-xs font-semibold text-primary transition hover:bg-primary hover:text-white md:inline-flex">
            Hubungi ↗
          </a>
          <button type="button" aria-label="Buka navigasi" onClick={() => setMenuOpen(!menuOpen)} className="flex h-9 w-9 flex-col items-center justify-center gap-1.5 md:hidden">
            <span className={`h-px w-5 bg-foreground transition ${menuOpen ? "translate-y-[4px] rotate-45" : ""}`} />
            <span className={`h-px w-5 bg-foreground transition ${menuOpen ? "-translate-y-[3px] -rotate-45" : ""}`} />
          </button>
        </nav>
        {menuOpen && (
          <div className="glass mx-auto mt-2 max-w-6xl rounded-3xl p-3 md:hidden">
            {NAV.map((item, index) => (
              <a key={item.id} href={`#${item.id}`} onClick={() => setMenuOpen(false)} className="flex items-center justify-between rounded-2xl px-4 py-3 text-sm hover:bg-primary/10">
                {item.label}<span className="font-mono text-xs text-primary">0{index + 1}</span>
              </a>
            ))}
          </div>
        )}
      </header>

      <main id="top" className="relative z-10 mx-auto max-w-6xl px-5">
        <section className="flex min-h-[92svh] flex-col justify-center pb-20 pt-36">
          <div className="reveal mb-7 inline-flex w-fit items-center gap-2 rounded-full border border-primary/25 bg-primary/5 px-4 py-2 font-mono text-[10px] tracking-[0.16em] text-primary">
            <span className="h-2 w-2 animate-pulse rounded-full bg-primary" /> DIGITAL CREATOR · DEVELOPER
          </div>
          <p className="reveal font-mono text-xs tracking-[0.35em] text-muted-foreground">INDEPENDENT DIGITAL PORTFOLIO</p>
          <h1 className="reveal mt-4 font-display text-[21vw] font-extrabold leading-[0.78] tracking-[-0.09em] sm:text-[8rem] md:text-[10rem]">
            REY<span className="text-gradient">2ND</span><span className="text-primary">.</span>
          </h1>
          <div className="reveal mt-8 grid gap-7 md:grid-cols-[1fr_auto] md:items-end">
            <div>
              <h2 className="font-display text-2xl font-semibold leading-tight sm:text-4xl">
                Turning ideas into<br /><span className="text-gradient">digital experiences.</span>
              </h2>
              <p className="mt-4 max-w-xl text-sm leading-7 text-muted-foreground sm:text-base">
                Saya membangun website, bot, dan eksperimen digital. Fokus pada tampilan yang rapi, fungsi yang jelas, dan pengalaman yang nyaman digunakan.
              </p>
            </div>
            <div className="flex flex-wrap gap-3">
              <a href="#projects" className="bg-gradient-brand rounded-full px-6 py-3 text-xs font-bold text-white shadow-[0_10px_35px_-12px_var(--violet)] transition hover:scale-105">LIHAT PROYEK ↗</a>
              <a href="#about" className="glass rounded-full px-6 py-3 text-xs font-semibold transition hover:border-primary/50">TENTANG SAYA</a>
            </div>
          </div>
          <div className="reveal mt-16 flex items-center justify-between border-t border-border pt-5 font-mono text-[10px] tracking-[0.2em] text-muted-foreground">
            <span>BASED IN INDONESIA</span><span>SCROLL TO EXPLORE ↓</span>
          </div>
        </section>

        <section id="about" className="scroll-mt-28 py-20 sm:py-28">
          <div className="reveal mb-10 flex items-center gap-4">
            <span className="font-mono text-xs text-primary">01 /</span>
            <h2 className="font-display text-3xl font-bold sm:text-5xl">Tentang Saya</h2>
            <span className="h-px flex-1 bg-border" />
          </div>
          <div className="grid gap-8 md:grid-cols-[1.2fr_0.8fr]">
            <div className="reveal">
              <p className="font-display text-2xl leading-relaxed sm:text-3xl">
                Bukan cuma membuat sesuatu terlihat bagus — saya ingin membuatnya <span className="text-gradient">berguna dan punya karakter.</span>
              </p>
              <p className="mt-6 max-w-2xl text-sm leading-8 text-muted-foreground">
                Saya tertarik pada dunia teknologi, pengembangan web, bot, dan produk digital. Setiap proyek menjadi ruang untuk mencoba ide baru, belajar hal teknis, dan memperbaiki detail dari waktu ke waktu.
              </p>
            </div>
            <div className="reveal grid gap-3 sm:grid-cols-2">
              {[
                ["01", "WEB", "Website & interface"],
                ["02", "BOTS", "Telegram & automation"],
                ["03", "TOOLS", "Tools & experiments"],
                ["04", "IDEAS", "Konsep jadi produk"],
              ].map(([num, title, desc]) => (
                <div key={num} className="glass glow-card rounded-2xl p-5">
                  <span className="font-mono text-[10px] text-primary">{num}</span>
                  <h3 className="mt-5 font-display text-xl font-bold">{title}</h3>
                  <p className="mt-1 text-xs text-muted-foreground">{desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="projects" className="scroll-mt-28 py-20 sm:py-28">
          <div className="reveal mb-10 flex items-center gap-4">
            <span className="font-mono text-xs text-primary">02 /</span>
            <h2 className="font-display text-3xl font-bold sm:text-5xl">Selected Projects</h2>
            <span className="h-px flex-1 bg-border" />
          </div>
          <p className="reveal mb-8 max-w-xl text-sm leading-7 text-muted-foreground">Beberapa proyek dan konsep yang sedang atau pernah saya kembangkan. Setiap kartu menjelaskan fokus dari masing-masing karya.</p>
          <div className="grid gap-4 lg:grid-cols-3">
            {PROJECTS.map((project) => (
              <article key={project.number} className="reveal glass glow-card group relative flex min-h-[340px] flex-col overflow-hidden rounded-[1.7rem] p-6">
                <div aria-hidden className="absolute -right-16 -top-16 h-48 w-48 rounded-full bg-violet/20 blur-[70px] transition group-hover:bg-violet/35" />
                <div className="relative flex items-center justify-between">
                  <span className="font-mono text-xs text-primary">{project.number} / PROJECT</span>
                  <span className="rounded-full border border-border px-3 py-1 font-mono text-[9px] text-muted-foreground">{project.status}</span>
                </div>
                <div className="relative my-12 flex h-24 items-center justify-center rounded-2xl border border-primary/15 bg-gradient-to-br from-primary/10 via-transparent to-violet/15">
                  <span className="font-display text-4xl font-extrabold tracking-tight text-gradient">{project.name}</span>
                </div>
                <p className="font-mono text-[9px] tracking-[0.18em] text-primary">{project.type}</p>
                <h3 className="mt-2 font-display text-2xl font-bold">{project.name}</h3>
                <p className="mt-3 flex-1 text-sm leading-7 text-muted-foreground">{project.description}</p>
                <div className="mt-6 flex flex-wrap gap-2">
                  {project.tags.map((tag) => <span key={tag} className="rounded-full border border-border px-3 py-1 font-mono text-[10px] text-muted-foreground">{tag}</span>)}
                </div>
              </article>
            ))}
          </div>
        </section>

        <section id="skills" className="scroll-mt-28 py-20 sm:py-28">
          <div className="reveal mb-10 flex items-center gap-4">
            <span className="font-mono text-xs text-primary">03 /</span>
            <h2 className="font-display text-3xl font-bold sm:text-5xl">Tools & Skills</h2>
            <span className="h-px flex-1 bg-border" />
          </div>
          <div className="grid gap-4 md:grid-cols-3">
            {SKILLS.map((group) => (
              <div key={group.title} className="reveal glass glow-card rounded-3xl p-6">
                <h3 className="font-mono text-[10px] tracking-[0.2em] text-primary">{group.title}</h3>
                <div className="mt-6 flex flex-wrap gap-2">
                  {group.items.map((skill) => <span key={skill} className="rounded-xl border border-border bg-secondary/50 px-3 py-2 text-xs text-foreground">{skill}</span>)}
                </div>
              </div>
            ))}
          </div>
        </section>

        <section id="contact" className="scroll-mt-28 py-20 sm:py-28">
          <div className="reveal glass relative overflow-hidden rounded-[2rem] p-7 sm:p-12">
            <div aria-hidden className="absolute -right-20 -top-24 h-72 w-72 rounded-full bg-violet/25 blur-[100px]" />
            <p className="font-mono text-xs tracking-[0.25em] text-primary">04 / CONTACT</p>
            <h2 className="relative mt-5 font-display text-4xl font-extrabold leading-tight sm:text-6xl">
              Let’s connect.<br /><span className="text-gradient">Find me here.</span>
            </h2>
            <p className="relative mt-5 max-w-xl text-sm leading-7 text-muted-foreground">
              Untuk pertanyaan, kolaborasi, atau project baru, hubungi saya melalui salah satu kontak berikut.
            </p>

            <div className="relative mt-9 grid gap-3 sm:grid-cols-3">
              <a
                href="https://t.me/TopsAlvaro"
                target="_blank"
                rel="noreferrer"
                className="group rounded-2xl border border-border bg-secondary/40 p-5 transition hover:-translate-y-1 hover:border-primary/50 hover:bg-primary/5"
              >
                <span className="font-mono text-[10px] tracking-[0.2em] text-primary">TELEGRAM</span>
                <span className="mt-3 block text-lg font-semibold text-foreground">@TopsAlvaro</span>
                <span className="mt-2 block text-xs text-muted-foreground">Kirim pesan ↗</span>
              </a>

              <a
                href="mailto:setyawanmahesa1@gmail.com"
                className="group rounded-2xl border border-border bg-secondary/40 p-5 transition hover:-translate-y-1 hover:border-primary/50 hover:bg-primary/5"
              >
                <span className="font-mono text-[10px] tracking-[0.2em] text-primary">EMAIL</span>
                <span className="mt-3 block break-all text-base font-semibold text-foreground">setyawanmahesa1@gmail.com</span>
                <span className="mt-2 block text-xs text-muted-foreground">Kirim email ↗</span>
              </a>

              <a
                href="https://github.com/rey2nd"
                target="_blank"
                rel="noreferrer"
                className="group rounded-2xl border border-border bg-secondary/40 p-5 transition hover:-translate-y-1 hover:border-primary/50 hover:bg-primary/5"
              >
                <span className="font-mono text-[10px] tracking-[0.2em] text-primary">GITHUB</span>
                <span className="mt-3 block text-lg font-semibold text-foreground">@rey2nd</span>
                <span className="mt-2 block text-xs text-muted-foreground">Lihat repository ↗</span>
              </a>
            </div>
          </div>
        </section>
      </main>

      <footer className="relative z-10 mx-auto flex max-w-6xl flex-col gap-3 border-t border-border px-5 py-8 font-mono text-[10px] tracking-[0.12em] text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
        <span>© {new Date().getFullYear()} REY2ND — DIGITAL PORTFOLIO</span>
        <a href="#top" className="transition hover:text-primary">BACK TO TOP ↑</a>
      </footer>
    </div>
  );
}
